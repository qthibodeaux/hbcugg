import { createContext, useContext, useMemo, useRef, useState } from "react";
import { Box, Flex, Grid, Image, Text } from "@chakra-ui/react";
import { ArrowRight, BarChart3, BookOpen, CalendarDays, Grid3x3, Map, Shield, Swords, TrendingUp } from "lucide-react";
import { TEAM_ANALYTICS_TABS } from "../../../pages/analytics/teamAnalyticsTabs";
import { SCATTER_PRESETS, scatterSeries } from "../../../pages/analytics/scatterPresets";
import { MATCHUP_FIELDS, matchupTable } from "../../../pages/analytics/matchupMetrics";
import { glossaryEntry } from "../../../pages/analytics/metricGlossary";
import { readableTeamColor } from "../../../utils/teamColor";

// ─────────────────────────────────────────────────────────────────────────────
// TEAM ANALYTICS TILE STRIP — the tab row as a 4x1 of live tiles.
//
// Eight equal-width portrait tiles fill the slot; each is the tab button AND
// the statistical verdict that tab exists to deliver, off the same hub /
// week-review data the tab reads. Not a thumbnail of the tab's chart — the
// one number a fan would click for:
//
//   Week        the winner's EPA edge next to the score — did we really get
//               beat that bad? (negative edge = no, you didn't)
//   Profile     the team's best unit and worst unit, by league percentile
//   Board       #1 and its gap to #2
//   Map         the quadrant — teams above the league on both levers
//   Matchup     the rating edge and the one lever that decides it
//   Rating Lab  the top lever's r² — how much of winning it explains
//   Trends      rank movement since the first season on file
//   Glossary    a term and its correlation with wins
//
// Every tile follows one vertical template: live readout on top (hero
// verdict → context → tease), and the tab itself as a big labelled bar at
// the bottom — that bar is what says "this is the tab", and the arrow on it
// is the call to open it. The strip is a size container, so everything is
// in cqmin (= the row unit). No px.
//
// Rotation is the CSS-driven pattern from Notable Performers: an invisible
// looping animation fires onAnimationIteration once a cycle, and the slide
// change plays as a live-tile transition (SlideStage). No useEffect, no
// setInterval, no progress bar.
// ─────────────────────────────────────────────────────────────────────────────

// Each tile rotates on its own cadence (see TILE_PARTS) so the strip never
// flips in lockstep. A rotation is a real transition between two slides —
// the outgoing readout leaves while the incoming one arrives — in the
// Windows live-tile vocabulary: slide, push, flip, cube, peek, fade. No
// hover motion anywhere on the strip.
const DEFAULT_ROTATE_MS = 5000;
const SLIDE_MS = 650;
const TileConfig = createContext({ rotateMs: DEFAULT_ROTATE_MS, transition: "slide" });
const BRAND = "#A855F7";
const POS = "#68D391";
const NEG = "#FC8181";

const TILE_KEYFRAMES = `
  @keyframes taTileTick { 0%, 100% { opacity: 1; } }
  @keyframes taTilePulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.35; transform: scale(0.7); } }
  @keyframes taTileMount { from { opacity: 0; transform: translateY(1.2em); } to { opacity: 1; transform: none; } }
  @keyframes taTileBreathe { 0%, 100% { filter: brightness(1); } 50% { filter: brightness(1.22); } }

  /* Inner-element arrivals used inside a slide (the Week bar). */
  @keyframes taTileGrowUp { from { transform: scaleY(0); } to { transform: scaleY(1); } }
  @keyframes taTileDrop { from { opacity: 0; transform: translateY(-0.6em); } to { opacity: 1; transform: translateY(0); } }
  @keyframes taTileRise { from { opacity: 0; transform: translateY(0.6em); } to { opacity: 1; transform: translateY(0); } }
  @keyframes taTilePop { from { opacity: 0; transform: scale(0.6); } 60% { transform: scale(1.08); } to { opacity: 1; transform: scale(1); } }
  .ta-tile-grow-up { transform-origin: bottom center; animation: taTileGrowUp 0.55s cubic-bezier(0.16, 1, 0.3, 1) both; }
  .ta-tile-grow-down { transform-origin: top center; animation: taTileGrowUp 0.55s cubic-bezier(0.16, 1, 0.3, 1) both; }
  .ta-tile-drop { animation: taTileDrop 0.5s 0.1s cubic-bezier(0.16, 1, 0.3, 1) both; }
  .ta-tile-rise { animation: taTileRise 0.5s 0.1s cubic-bezier(0.16, 1, 0.3, 1) both; }
  .ta-tile-pop { animation: taTilePop 0.5s 0.25s cubic-bezier(0.16, 1, 0.3, 1) both; }

  /* ── Slide transitions: each has an -out (leaving) and an -in (arriving) ── */
  /* slide — Windows' default: the tile scrolls up to the next item. */
  @keyframes taSlideOut { from { transform: translateY(0); opacity: 1; } to { transform: translateY(-100%); opacity: 0; } }
  @keyframes taSlideIn  { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  /* push — horizontal: old pushed off left, new pushed in from the right. */
  @keyframes taPushOut  { from { transform: translateX(0); opacity: 1; } to { transform: translateX(-100%); opacity: 0; } }
  @keyframes taPushIn   { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
  /* flip — the tile turns over on its horizontal axis; new face on the back. */
  @keyframes taFlipOut  { from { transform: rotateX(0); opacity: 1; } 50%, to { transform: rotateX(90deg); opacity: 0; } }
  @keyframes taFlipIn   { from, 50% { transform: rotateX(-90deg); opacity: 0; } to { transform: rotateX(0); opacity: 1; } }
  /* cube — the tile rotates on its vertical axis like a face of a cube. */
  @keyframes taCubeOut  { from { transform: translateX(0) rotateY(0); opacity: 1; } to { transform: translateX(-60%) rotateY(-90deg); opacity: 0; } }
  @keyframes taCubeIn   { from { transform: translateX(60%) rotateY(90deg); opacity: 0; } to { transform: translateX(0) rotateY(0); opacity: 1; } }
  /* peek — the new item rises up over the old, which stays put underneath. */
  @keyframes taPeekOut  { from, to { transform: none; opacity: 1; } }
  @keyframes taPeekIn   { from { transform: translateY(100%); } to { transform: translateY(0); } }
  /* fade — crossfade. */
  @keyframes taFadeOut  { from { opacity: 1; } to { opacity: 0; } }
  @keyframes taFadeIn   { from { opacity: 0; } to { opacity: 1; } }
  /* zoom — old sinks back, new lands from in front. */
  @keyframes taZoomOut  { from { transform: scale(1); opacity: 1; } to { transform: scale(0.8); opacity: 0; } }
  @keyframes taZoomIn   { from { transform: scale(1.2); opacity: 0; } to { transform: scale(1); opacity: 1; } }

  .ta-slide-stage { position: relative; perspective: 80cqmin; }
  .ta-slide-layer { backface-visibility: hidden; transform-origin: center center; }
  .ta-slide-prev { position: absolute; inset: 0; pointer-events: none; }
  .ta-x-slide-out { animation: taSlideOut ${SLIDE_MS}ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  .ta-x-slide-in  { animation: taSlideIn ${SLIDE_MS}ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  .ta-x-push-out  { animation: taPushOut ${SLIDE_MS}ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  .ta-x-push-in   { animation: taPushIn ${SLIDE_MS}ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  .ta-x-flip-out  { transform-origin: center center; animation: taFlipOut ${SLIDE_MS}ms ease-in both; }
  .ta-x-flip-in   { transform-origin: center center; animation: taFlipIn ${SLIDE_MS}ms ease-out both; }
  .ta-x-cube-out  { transform-origin: right center; animation: taCubeOut ${SLIDE_MS}ms ease-in-out both; }
  .ta-x-cube-in   { transform-origin: left center; animation: taCubeIn ${SLIDE_MS}ms ease-in-out both; }
  .ta-x-peek-out  { animation: taPeekOut ${SLIDE_MS}ms linear both; }
  .ta-x-peek-in   { animation: taPeekIn ${SLIDE_MS}ms cubic-bezier(0.2, 0.8, 0.2, 1) both; }
  .ta-x-fade-out  { animation: taFadeOut ${SLIDE_MS}ms ease both; }
  .ta-x-fade-in   { animation: taFadeIn ${SLIDE_MS}ms ease both; }
  .ta-x-zoom-out  { animation: taZoomOut ${SLIDE_MS}ms ease-in both; }
  .ta-x-zoom-in   { animation: taZoomIn ${SLIDE_MS}ms ease-out both; }

  /* Page-load stagger: tiles arrive left to right. */
  .ta-tile-mount { animation: taTileMount 0.6s cubic-bezier(0.16, 1, 0.3, 1) both; animation-delay: var(--ta-mount-delay, 0ms); }
  .ta-tile-breathe { animation: taTileBreathe 3.2s ease-in-out infinite; }
  .ta-tile-tick { animation: taTileTick var(--ta-rotate, ${DEFAULT_ROTATE_MS}ms) linear infinite; }
  .ta-tile-pulse { animation: taTilePulse 1.6s ease-in-out infinite; }
  .ta-tile-val { animation: taFadeIn 260ms ease both; }
  @media (prefers-reduced-motion: reduce) {
    [class*="ta-x-"], .ta-tile-pulse, .ta-tile-val, .ta-tile-grow-up, .ta-tile-grow-down, .ta-tile-drop, .ta-tile-rise, .ta-tile-pop, .ta-tile-mount, .ta-tile-breathe { animation: none !important; }
    .ta-slide-prev { display: none; }
  }
`;

// Week review games carry margin + net_success + winner_edge today; epa_diff
// is on the contract but not on the file yet. Until it ships, a deterministic
// stand-in off the margin keeps the tile honest about its layout. Delete
// mockEpaDiff the day `epa_diff` lands — the read order prefers the real field.
const mockEpaDiff = (g) => (Number.isFinite(g?.margin) ? Number((g.margin * 0.62 + ((g.margin % 3) - 1) * 2.4 - (g.margin % 5) * 1.7).toFixed(1)) : null);

const fmtSigned = (v, d = 1) => (Number.isFinite(v) ? `${v > 0 ? "+" : ""}${v.toFixed(d)}` : "—");

// Never the same clock twice: every cycle picks a fresh interval in the
// 5–12s band, seeded off the tile's own base so the eight tiles stay out of
// phase with each other as well as with themselves. The animation restarts
// (key) with the new duration after each tick.
const ROTATE_MIN_MS = 5000;
const ROTATE_MAX_MS = 12000;
const jitteredMs = (base, n) => {
  const x = Math.abs(Math.sin((base + 1) * 0.0007 + n * 12.9898) * 43758.5453);
  const t = x - Math.floor(x);
  return Math.round(ROTATE_MIN_MS + t * (ROTATE_MAX_MS - ROTATE_MIN_MS));
};

const Rotator = ({ count, onTick, baseMs }) => {
  const ctx = useContext(TileConfig);
  const rotateMs = baseMs ?? ctx.rotateMs;
  const [n, setN] = useState(0);
  if (count <= 1) return null;
  return (
    <Box
      key={n}
      className="ta-tile-tick"
      w={0}
      h={0}
      overflow="hidden"
      style={{ "--ta-rotate": `${jitteredMs(rotateMs, n)}ms` }}
      onAnimationIteration={() => { setN((v) => v + 1); onTick(); }}
    />
  );
};

const Mark = ({ logo, label, size = 7 }) =>
  logo ? (
    <Image src={logo} alt="" w={`${size}cqmin`} h={`${size}cqmin`} objectFit="contain" flexShrink={0} />
  ) : (
    <Flex w={`${size}cqmin`} h={`${size}cqmin`} align="center" justify="center" borderRadius="sm" bg="whiteAlpha.100" flexShrink={0}>
      <Text fontSize={`${size * 0.34}cqmin`} fontWeight="black" color="whiteAlpha.700" lineClamp={1}>{String(label ?? "?").slice(0, 3).toUpperCase()}</Text>
    </Flex>
  );

// ── Template atoms ───────────────────────────────────────────────────────────

const Micro = ({ children, color = "rgba(255,255,255,0.45)", size = 2.4, ...rest }) => (
  <Text fontSize={`${size}cqmin`} fontWeight="black" color={color} textTransform="uppercase" letterSpacing="0.14em" lineHeight={1.25} lineClamp={2} {...rest}>
    {children}
  </Text>
);

const Hero = ({ children, color = "white", size = 11, ...rest }) => (
  <Text fontSize={`${size}cqmin`} fontWeight="black" color={color} lineHeight={0.9} letterSpacing="-0.04em" fontVariantNumeric="tabular-nums" lineClamp={1} {...rest}>
    {children}
  </Text>
);

const Context = ({ children, color = "rgba(255,255,255,0.8)", ...rest }) => (
  <Text fontSize="3cqmin" fontWeight="black" color={color} textTransform="uppercase" letterSpacing="0.04em" lineHeight={1.15} lineClamp={2} {...rest}>
    {children}
  </Text>
);

// The tab bar is rendered by the strip; the body owns the live readout.
// `cycle` changes each rotation and drives the slide transition; `live`
// shows the pulse dot so a rotating tile reads as rotating.
// The slide stage. Holds the outgoing slide as a snapshot for one transition
// so it can animate out underneath / over the incoming one — a real
// transition between two states, not a remount. Snapshot is derived state
// (set during render on cycle change), and dropped when its exit animation
// ends; no effects.
const SlideStage = ({ cycle, children }) => {
  const { transition } = useContext(TileConfig);
  const latest = useRef(children);
  const [stage, setStage] = useState({ cycle, prev: null, prevCycle: null });
  if (stage.cycle !== cycle) {
    setStage({ cycle, prev: latest.current, prevCycle: stage.cycle });
  }
  latest.current = children;
  const animate = stage.prev != null;
  return (
    <Box className="ta-slide-stage" minW={0} flex={1} minH={0} display="flex" flexDirection="column" overflow={transition === "flip" || transition === "cube" ? "visible" : "hidden"}>
      <Flex key={`in-${cycle}`} className={`ta-slide-layer ${animate ? `ta-x-${transition}-in` : ""}`} minW={0} flex={1} minH={0} direction="column" justify="center" position="relative" zIndex={transition === "peek" ? 2 : 1}>
        {children}
      </Flex>
      {animate && (
        <Flex
          key={`out-${stage.prevCycle}`}
          className={`ta-slide-layer ta-slide-prev ta-x-${transition}-out`}
          direction="column"
          justify="center"
          zIndex={transition === "peek" ? 1 : 2}
          onAnimationEnd={() => setStage((st) => ({ ...st, prev: null, prevCycle: null }))}
        >
          {stage.prev}
        </Flex>
      )}
    </Box>
  );
};

const Body = ({ top = null, children, tease, cycle = 0, live = false }) => {
  return (
    <Flex direction="column" flex={1} minH={0} justify="space-between" gap="2cqmin">
      <Flex align="flex-start" justify="space-between" gap="1cqmin" minW={0}>
        <Box minW={0} flex={1}>{top}</Box>
        {live && <Box className="ta-tile-pulse" w="1.6cqmin" h="1.6cqmin" borderRadius="full" bg={BRAND} flexShrink={0} mt="0.6cqmin" />}
      </Flex>
      <SlideStage cycle={cycle}>{children}</SlideStage>
      {tease && <Box minW={0}>{tease}</Box>}
    </Flex>
  );
};

const Empty = ({ children = "No data" }) => (
  <Flex flex={1} align="center" justify="center">
    <Micro color="rgba(255,255,255,0.3)">{children}</Micro>
  </Flex>
);

// ── Week Review — did we really get beat that bad? ───────────────────────────
// Always the most recent week that has games (the backend's default week
// when it has games, else the last played week). The readout is a standard
// bar, one game at a time: winner's logo, an axis, a bar dropping from the
// axis in the winner's colour with the winner's EPA edge on it, the loser's
// logo under. The bar does not mirror the chart's direction — it is the
// same shape every game; the number's colour carries the sign. Rotates
// through the week's most contrarian games (up to three, however many
// there are).

const WeekBar = ({ winner, loser, edge, cycle }) => {
  const color = winner?.primary && winner.primary !== "#000000" ? winner.primary : BRAND;
  const numberColor = Number.isFinite(edge) ? (edge >= 0 ? POS : NEG) : "rgba(255,255,255,0.6)";
  return (
    <Flex direction="column" align="center" h="40cqmin" w="100%">
      <Box key={`w-${cycle}`} className="ta-tile-drop" flexShrink={0}>
        <Mark logo={winner?.logo} label={winner?.short} size={9} />
      </Box>
      <Box h="0.5cqmin" w="100%" bg="rgba(255,255,255,0.6)" borderRadius="full" mt="1.2cqmin" flexShrink={0} />
      <Flex
        key={`bar-${cycle}`}
        className="ta-tile-grow-down ta-tile-breathe"
        flex={1}
        minH={0}
        w="62%"
        bg={color}
        borderBottomRadius="1cqmin"
        align="center"
        justify="center"
        boxShadow={`0 0 3cqmin ${color}55`}
      >
        <Text
          key={`n-${cycle}`}
          className="ta-tile-pop"
          fontSize="8cqmin"
          fontWeight="black"
          color={numberColor}
          lineHeight={1}
          letterSpacing="-0.04em"
          fontVariantNumeric="tabular-nums"
          textShadow="0 0 1.2cqmin rgba(0,0,0,0.9), 0 0.3cqmin 0.8cqmin rgba(0,0,0,0.8)"
        >
          {fmtSigned(edge)}
        </Text>
      </Flex>
      <Box key={`l-${cycle}`} className="ta-tile-rise" mt="1.5cqmin" flexShrink={0}>
        <Mark logo={loser?.logo} label={loser?.short} size={6} />
      </Box>
    </Flex>
  );
};

const WeekBody = ({ review }) => {
  const games = useMemo(() => {
    const weeks = Array.isArray(review?.weeks) ? review.weeks : [];
    const played = weeks.filter((w) => w.played && w.games?.length);
    const preferred = review?.defaultWeek ?? review?.default_week;
    const week = played.find((w) => w.week === preferred) ?? played[played.length - 1] ?? null;
    if (!week) return { week: null, list: [] };
    const list = week.games
      .map((g) => ({ ...g, edge: Number.isFinite(g.epa_diff) ? g.epa_diff : mockEpaDiff(g) }))
      .filter((g) => g.winner_id)
      .sort((a, b) => (a.edge ?? Infinity) - (b.edge ?? Infinity))
      .slice(0, 3);
    return { week, list };
  }, [review]);
  const [i, setI] = useState(0);
  const g = games.list[i % Math.max(1, games.list.length)];
  if (!g) return <Empty>No games yet</Empty>;

  const winner = g.winner_id === g.home?.id ? g.home : g.away;
  const loser = winner === g.home ? g.away : g.home;

  return (
    <Body
      cycle={i}
      live={games.list.length > 1}
      top={
        <>
          <Rotator count={games.list.length} onTick={() => setI((v) => (v + 1) % games.list.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            {games.week.label}
          </Text>
        </>
      }
    >
      <WeekBar winner={winner} loser={loser} edge={g.edge} cycle={i} />
    </Body>
  );
};

// ── Team Profile — six stats, six leaders ────────────────────────────────────
// One stat per slide, shown for the team that leads the league in it: the
// number huge (the sell), the label under it, the leader's logo big and
// offset behind. Record carries no label — the score line is its own label.
//
// MOCK: adj EPA/play, EPA/play, yards/play and overall success rate are not
// on the hub file (team-season EPA is the Stats doc §7.1 backend ask). Until
// they ship they're a deterministic stand-in off the composite rating so the
// tile holds its layout; slides built on them carry a "mock" tag. Record and
// Glory rating (the composite) are real.

const PROFILE_STATS = [
  { id: "record", label: null, mock: false, value: (r) => r.record?.pct, text: (r) => r.record?.record ?? "—" },
  { id: "adj_epa", label: "Adj EPA / Play", mock: true, value: (r) => r.mock_adj_epa, text: (r) => fmtSigned(r.mock_adj_epa, 2) },
  { id: "epa", label: "EPA / Play", mock: true, value: (r) => r.mock_epa, text: (r) => fmtSigned(r.mock_epa, 2) },
  { id: "ypp", label: "Yards / Play", mock: true, value: (r) => r.mock_ypp, text: (r) => (Number.isFinite(r.mock_ypp) ? r.mock_ypp.toFixed(1) : "—") },
  { id: "sr", label: "Success Rate", mock: true, value: (r) => r.mock_sr, text: (r) => (Number.isFinite(r.mock_sr) ? `${Math.round(r.mock_sr * 100)}%` : "—") },
  { id: "glory", label: "Glory Rating", mock: false, value: (r) => r.rating, text: (r) => fmtSigned(r.rating, 2) },
];

const withMockSeason = (row, idx) => {
  const r = Number.isFinite(row?.rating) ? row.rating : 0;
  const wobble = ((idx * 37) % 11) / 100 - 0.05;
  return {
    ...row,
    mock_epa: Number((0.02 + r * 0.12 + wobble * 0.3).toFixed(3)),
    mock_adj_epa: Number((0.03 + r * 0.13 - wobble * 0.2).toFixed(3)),
    mock_ypp: Number((5.4 + r * 0.6 + wobble * 2).toFixed(2)),
    mock_sr: Number((0.41 + r * 0.045 + wobble * 0.2).toFixed(3)),
  };
};

const ProfileBody = ({ hub, season }) => {
  const slides = useMemo(() => {
    const rows = Object.values(hub.teams ?? {})
      .map((t, idx) => ({ team: t, row: t.seasons?.[season] ? withMockSeason(t.seasons[season], idx) : null }))
      .filter((x) => x.row);
    return PROFILE_STATS.map((stat) => {
      const leader = rows
        .filter((x) => Number.isFinite(stat.value(x.row)))
        .sort((a, b) => stat.value(b.row) - stat.value(a.row))[0];
      return leader ? { stat, team: leader.team, row: leader.row } : null;
    }).filter(Boolean);
  }, [hub.teams, season]);
  const [i, setI] = useState(0);
  if (!slides.length) return <Empty>No season on file</Empty>;
  const { stat, team, row } = slides[i % slides.length];
  return (
    <Body
      cycle={i}
      live={slides.length > 1}
      top={
        <>
          <Rotator count={slides.length} onTick={() => setI((v) => (v + 1) % slides.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            Leader
          </Text>

        </>
      }
    >
      <Box position="relative" flex={1} minH="36cqmin" minW={0}>
        <Flex position="absolute" inset={0} align="center" justify="center" opacity={0.2} pointerEvents="none">
          <Mark logo={team.identity.logo} label={team.identity.short} size={46} />
        </Flex>
        <Flex position="relative" direction="column" align="center" justify="center" h="100%" minW={0} textAlign="center">
          <Text fontSize={stat.id === "record" ? "16cqmin" : "14cqmin"} fontWeight="black" fontStyle="italic" color="white" lineHeight={0.9} letterSpacing="-0.05em" fontVariantNumeric="tabular-nums" lineClamp={1} textShadow="0 0 2cqmin rgba(0,0,0,0.8)">
            {stat.text(row)}
          </Text>
          {stat.label && <Context mt="1cqmin" color="rgba(255,255,255,0.8)" textAlign="center">{stat.label}</Context>}
        </Flex>
      </Box>
    </Body>
  );
};

// ── Board — #1 and the gap ───────────────────────────────────────────────────

// Leader Board: who's best at X. One slide per Board column — the composite
// rating and the five strongest win levers — showing the league leader's
// actual value huge, the stat name under it, and the rank after. The team's
// logo sits big behind. Same template as Team Profile.
const fmtMetric = (v, unit) => (!Number.isFinite(v) ? "—" : unit === "pct" ? `${(v * 100).toFixed(1)}%` : v.toFixed(2));

const BoardBody = ({ hub, season }) => {
  const slides = useMemo(() => {
    const rows = Object.values(hub.teams ?? {})
      .map((t) => ({ t, s: t.seasons?.[season] }))
      .filter((x) => x.s);
    const columns = [
      { key: "rating", label: "Glory Rating", value: (x) => x.s.rating, text: (x) => fmtSigned(x.s.rating, 2), good: true },
      ...(hub.levers ?? []).slice(0, 5).map((l) => ({
        key: l.field,
        label: l.short,
        value: (x) => x.s.metrics?.[l.field],
        text: (x) => fmtMetric(x.s.metrics?.[l.field], l.unit),
        good: l.good,
      })),
    ];
    return columns
      .map((c) => {
        const leader = rows
          .filter((x) => Number.isFinite(c.value(x)))
          .sort((a, b) => (c.good ? c.value(b) - c.value(a) : c.value(a) - c.value(b)))[0];
        return leader ? { column: c, ...leader } : null;
      })
      .filter(Boolean);
  }, [hub.teams, hub.levers, season]);
  const [i, setI] = useState(0);
  if (!slides.length) return <Empty>No season on file</Empty>;
  const { column, t, s: row } = slides[i % slides.length];
  return (
    <Body
      cycle={i}
      live={slides.length > 1}
      top={
        <>
          <Rotator count={slides.length} onTick={() => setI((v) => (v + 1) % slides.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            Rankings
          </Text>
        </>
      }
    >
      <Box position="relative" flex={1} minH="36cqmin" minW={0}>
        <Flex position="absolute" inset={0} align="center" justify="center" opacity={0.2} pointerEvents="none">
          <Mark logo={t.identity.logo} label={t.identity.short} size={46} />
        </Flex>
        <Flex position="relative" direction="column" align="center" justify="center" h="100%" minW={0} textAlign="center">
          <Text fontSize="14cqmin" fontWeight="black" fontStyle="italic" color="white" lineHeight={0.9} letterSpacing="-0.05em" fontVariantNumeric="tabular-nums" lineClamp={1} textShadow="0 0 2cqmin rgba(0,0,0,0.8)">
            {column.text({ t, s: row })}
          </Text>
          <Context mt="1cqmin" color="rgba(255,255,255,0.8)" textAlign="center">{column.label}</Context>
          <Text fontSize="5cqmin" fontWeight="black" fontStyle="italic" color={BRAND} lineHeight={1} mt="1cqmin" fontVariantNumeric="tabular-nums">#1</Text>
        </Flex>
      </Box>
    </Body>
  );
};

// ── Scatter — the preset charts ──────────────────────────────────────────────
// One preset per slide: all 18 teams as plain dots, the league average as a
// crosshair, and the chart's biggest outlier swapped for its logo — the dot
// worth asking about. Axes are labelled on the plot; the chart's name sits
// under it. The presets are shared with the tab (scatterPresets.js), so the
// tile is a preview of a chart the tab can actually draw.

const ScatterPlot = ({ points, avgX, avgY }) => {
  const PAD = 12;
  const span = (vals) => {
    const lo = Math.min(...vals), hi = Math.max(...vals);
    const m = (hi - lo) * 0.16 || 0.01;
    return [lo - m, hi + m];
  };
  const [x0, x1] = span(points.map((p) => p.x));
  const [y0, y1] = span(points.map((p) => p.y));
  const px = (v) => PAD + ((v - x0) / (x1 - x0)) * (100 - PAD * 2);
  const py = (v) => 100 - PAD - ((v - y0) / (y1 - y0)) * (100 - PAD * 2);
  // The dot furthest from the league average, in normalised units — the one
  // the chart is really about.
  const outlier = points.reduce((best, p) => {
    const d = ((p.x - avgX) / (x1 - x0)) ** 2 + ((p.y - avgY) / (y1 - y0)) ** 2;
    return best == null || d > best.d ? { p, d } : best;
  }, null)?.p;

  return (
    <Box w="100%" flex={1} minH={0}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" width="100%" height="100%" style={{ display: "block" }}>
        {/* crosshair = league average */}
        <line x1={px(avgX)} y1={PAD * 0.4} x2={px(avgX)} y2={100 - PAD * 0.6} stroke="rgba(255,255,255,0.16)" strokeWidth="0.6" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" />
        <line x1={PAD * 0.4} y1={py(avgY)} x2={100 - PAD * 0.4} y2={py(avgY)} stroke="rgba(255,255,255,0.16)" strokeWidth="0.6" strokeDasharray="2 2" vectorEffect="non-scaling-stroke" />
        {points.map((p) =>
          p === outlier ? null : (
            <circle key={p.id} cx={px(p.x)} cy={py(p.y)} r="2.6" fill="#3F3F46" />
          ),
        )}
        {outlier && (
          <g>
            <circle cx={px(outlier.x)} cy={py(outlier.y)} r="11" fill="rgba(10,10,12,0.75)" stroke={outlier.color ?? BRAND} strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
            {outlier.logo ? (
              <image href={outlier.logo} x={px(outlier.x) - 8} y={py(outlier.y) - 8} width="16" height="16" preserveAspectRatio="xMidYMid meet" />
            ) : (
              <text x={px(outlier.x)} y={py(outlier.y) + 2.5} textAnchor="middle" fill="white" fontSize="7" fontWeight="900">{outlier.short}</text>
            )}
          </g>
        )}
      </svg>
    </Box>
  );
};

const MapBody = ({ hub, season }) => {
  const [i, setI] = useState(0);
  const preset = SCATTER_PRESETS[i % SCATTER_PRESETS.length];
  const chart = useMemo(() => scatterSeries(hub, season, preset.x, preset.y), [hub, season, preset]);
  if (!chart.points.length) return <Empty>No season on file</Empty>;
  return (
    <Body
      cycle={i}
      live={SCATTER_PRESETS.length > 1}
      top={
        <>
          <Rotator count={SCATTER_PRESETS.length} onTick={() => setI((v) => (v + 1) % SCATTER_PRESETS.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            Scatter
          </Text>
        </>
      }
    >
      <Flex direction="column" flex={1} minH={0} minW={0} gap="1cqmin">
        <Micro size={2.1} textAlign="center">↑ {chart.y.label}</Micro>
        <ScatterPlot {...chart} />
        <Micro size={2.1} textAlign="center">{chart.x.label} →</Micro>
        <Context mt="0.8cqmin" textAlign="center">{preset.label}</Context>
      </Flex>
    </Body>
  );
};

// ── Matchup — three bands, three clocks ──────────────────────────────────────
// Not one rotating readout but three stacked ones: a team, the stat that
// separates them, the other team. Each band keeps its own clock and its own
// transition, so the tile is never doing one thing — it reads like a split
// flap board settling one row at a time.
//
// The middle band owns the STAT: that is what its clock rotates and what its
// flip animates. The number itself is derived live from whichever two teams
// are showing right now, so a team band flipping underneath can never leave a
// stale number behind — the digits just cross-fade in place.
//
// The pool is four teams drawn at random on load, and the bottom band skips
// whoever is on top so the tile never faces a team against itself.
//
// MOCK: the four stats are the stand-in matchup fields (see
// src/pages/analytics/matchupMetrics.js), not yet on the hub file.

const MATCHUP_TILE_STATS = [
  { key: "net_epa", label: "EPA / Play" },
  { key: "o_success", label: "Success Rate" },
  { key: "net_epa_drive", label: "EPA / Drive" },
  { key: "net_fp", label: "Field Position" },
];
const MATCHUP_POOL_SIZE = 4;

const fmtDiff = (v, unit) => {
  if (!Number.isFinite(v)) return "—";
  const sign = v > 0 ? "+" : v < 0 ? "-" : "";
  const mag = Math.abs(v);
  if (unit === "pct") return `${sign}${(mag * 100).toFixed(1)}%`;
  if (unit === "num1" || unit === "fp") return `${sign}${mag.toFixed(1)}`;
  return `${sign}${mag.toFixed(2)}`;
};

// One band: its own clock, its own transition, its own slide stage.
const Band = ({ transition, baseMs, count, onTick, cycle, flex = 1, divider = false, children }) => (
  <TileConfig.Provider value={{ rotateMs: baseMs, transition }}>
    <Flex
      direction="column" flex={flex} minH={0} minW={0} position="relative"
      borderTop={divider ? "1px solid" : undefined} borderColor="whiteAlpha.200"
    >
      <Rotator count={count} onTick={onTick} baseMs={baseMs} />
      <SlideStage cycle={cycle}>{children}</SlideStage>
    </Flex>
  </TileConfig.Provider>
);

// A team band: oversize ghost logo bled off one corner, standard logo in front.
const TeamFace = ({ team, side }) => (
  <Flex position="relative" flex={1} minH={0} align="center" justify="center" overflow="hidden">
    <Box
      position="absolute" opacity={0.16} pointerEvents="none"
      {...(side === "top" ? { left: "-9cqmin", top: "-7cqmin" } : { right: "-9cqmin", bottom: "-7cqmin" })}
    >
      <Mark logo={team.identity.logo} label={team.identity.short} size={30} />
    </Box>
    <Box position="relative">
      <Mark logo={team.identity.logo} label={team.identity.short} size={11} />
    </Box>
  </Flex>
);

const MatchupBody = ({ hub, season }) => {
  // Random on load: a fresh four every time the strip mounts.
  const pool = useMemo(() => {
    const rows = Object.values(hub.teams ?? {}).filter((t) => t.seasons?.[season]);
    for (let i = rows.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [rows[i], rows[j]] = [rows[j], rows[i]];
    }
    return rows.slice(0, MATCHUP_POOL_SIZE);
  }, [hub.teams, season]);
  const tape = useMemo(() => matchupTable(hub, season), [hub, season]);

  const [top, setTop] = useState(0);
  const [bottom, setBottom] = useState(1);
  const [stat, setStat] = useState(0);

  if (pool.length < 2) return <Empty>No season on file</Empty>;

  const n = pool.length;
  const a = pool[top % n];
  // The bottom band runs its own clock but never lands on the team up top.
  const b = pool[bottom % n === top % n ? (bottom + 1) % n : bottom % n];
  const st = MATCHUP_TILE_STATS[stat % MATCHUP_TILE_STATS.length];

  const unit = MATCHUP_FIELDS[st.key]?.unit;
  const va = tape.values[a.identity.id]?.[st.key];
  const vb = tape.values[b.identity.id]?.[st.key];
  const diff = Number.isFinite(va) && Number.isFinite(vb) ? va - vb : undefined;
  // Raw sign, from the top team's point of view; colour says who is better.
  const better = MATCHUP_FIELDS[st.key]?.high ? diff > 0 : diff < 0;
  const tone = !Number.isFinite(diff) || diff === 0 ? "rgba(255,255,255,0.75)" : better ? POS : NEG;

  return (
    <Flex direction="column" flex={1} minH={0} minW={0}>
      <Band transition="push" baseMs={6000} count={n} cycle={top} onTick={() => setTop((v) => (v + 1) % n)}>
        <TeamFace team={a} side="top" />
      </Band>

      <Band
        transition="flip" baseMs={9000} flex={1.15} divider
        count={MATCHUP_TILE_STATS.length} cycle={stat}
        onTick={() => setStat((v) => (v + 1) % MATCHUP_TILE_STATS.length)}
      >
        <Flex direction="column" flex={1} minH={0} align="center" justify="center" textAlign="center" px="1cqmin">
          <Text
            key={`${a.identity.id}-${b.identity.id}-${st.key}`}
            className="ta-tile-val"
            fontSize="10.5cqmin" fontWeight="black" fontStyle="italic" color={tone}
            lineHeight={0.9} letterSpacing="-0.05em" fontVariantNumeric="tabular-nums" lineClamp={1}
          >
            {fmtDiff(diff, unit)}
          </Text>
          <Context mt="1cqmin" color="rgba(255,255,255,0.7)" textAlign="center">{st.label} diff</Context>
        </Flex>
      </Band>

      <Band transition="cube" baseMs={7500} divider count={n} cycle={bottom} onTick={() => setBottom((v) => (v + 1) % n)}>
        <TeamFace team={b} side="bottom" />
      </Band>
    </Flex>
  );
};

// ── Rating Lab — what wins games ─────────────────────────────────────────────
// Same template as Leader Board minus the team: a big rotating number and the
// stat under it. The number is the metric's correlation with winning, so the
// tile is the tab's whole premise at a glance — green pulls wins, red costs
// them. No logo behind it; this slide is about the league, not a team.

const LabBody = ({ hub }) => {
  const levers = useMemo(
    () => (hub.levers ?? []).filter((l) => l.abs >= 0.25).slice(0, 6),
    [hub.levers],
  );
  const [i, setI] = useState(0);
  if (!levers.length) return <Empty>No levers on file</Empty>;
  const lever = levers[i % levers.length];
  return (
    <Body
      cycle={i}
      live={levers.length > 1}
      top={
        <>
          <Rotator count={levers.length} onTick={() => setI((v) => (v + 1) % levers.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            What Wins
          </Text>
        </>
      }
    >
      <Flex direction="column" align="center" justify="center" flex={1} minH="36cqmin" minW={0} textAlign="center">
        <Text
          fontSize="14cqmin" fontWeight="black" fontStyle="italic" color={lever.r >= 0 ? POS : NEG}
          lineHeight={0.9} letterSpacing="-0.05em" fontVariantNumeric="tabular-nums" lineClamp={1}
        >
          {fmtSigned(lever.r, 2)}
        </Text>
        <Context mt="1cqmin" color="rgba(255,255,255,0.8)" textAlign="center">{lever.label ?? lever.short}</Context>
      </Flex>
    </Body>
  );
};

// ── Trends — a team, a stat, the line ────────────────────────────────────────
// Four slides drawn fresh on every load: four random teams paired with four
// random stats, each showing that team's line across every season we hold.
// The line is real — the hub carries six seasons of every one of these — so
// the shape is the team's actual arc, not decoration.

const TREND_TILE_STATS = [
  { key: "rating", label: "Glory Rating", unit: "num", signed: true },
  { key: "o_rushing.successRate", label: "Rush Success", unit: "pct" },
  { key: "o_rushing.opportunityRate", label: "Opportunity Rate", unit: "pct" },
  { key: "o_passing.ypa", label: "Yards / Attempt", unit: "num" },
  { key: "o_passing.explosiveRate", label: "Explosive Rate", unit: "pct" },
  { key: "d_rushing.successRate", label: "Rush Success Allowed", unit: "pct" },
  { key: "d_passing.completionRate", label: "Completion Allowed", unit: "pct" },
  { key: "d_passing.pressureRate", label: "Pressure Rate", unit: "pct" },
];
const TREND_TILE_SLIDES = 4;

const readTrend = (row, key) => (key === "rating" ? row?.rating : row?.metrics?.[key]);

// A shuffled draw of n, without repeats.
const drawSome = (list, n) => {
  const pool = [...list];
  for (let i = pool.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, n);
};

const Sparkline = ({ points, color }) => {
  if (points.length < 2) return null;
  const lo = Math.min(...points);
  const hi = Math.max(...points);
  const span = hi - lo || 1;
  const xy = points.map((v, i) => [(i / (points.length - 1)) * 100, 26 - ((v - lo) / span) * 22]);
  const line = xy.map(([x, y]) => `${x},${y}`).join(" ");
  const last = xy[xy.length - 1];
  return (
    <svg viewBox="0 0 100 30" width="100%" height="100%" preserveAspectRatio="none" style={{ display: "block", overflow: "visible" }}>
      <polyline points={line} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />
      {xy.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="1.1" fill={color} opacity={0.55} vectorEffect="non-scaling-stroke" />
      ))}
      <circle cx={last[0]} cy={last[1]} r="2.1" fill={color} vectorEffect="non-scaling-stroke" />
    </svg>
  );
};

const TrendsBody = ({ hub }) => {
  // Random on load: four team-and-stat pairings, each with a full line.
  const slides = useMemo(() => {
    const seasons = (hub.seasons ?? []).slice().sort((a, b) => a - b);
    const teams = Object.values(hub.teams ?? {});
    return drawSome(teams, TREND_TILE_SLIDES)
      .map((team, i) => {
        const stat = drawSome(TREND_TILE_STATS, TREND_TILE_SLIDES)[i % TREND_TILE_SLIDES];
        const points = seasons
          .map((y) => readTrend(team.seasons?.[y], stat.key))
          .filter((v) => Number.isFinite(v));
        return points.length >= 2 ? { team, stat, points } : null;
      })
      .filter(Boolean);
  }, [hub.teams, hub.seasons]);

  const [i, setI] = useState(0);
  if (!slides.length) return <Empty>Not enough seasons</Empty>;
  const { team, stat, points } = slides[i % slides.length];
  const latest = points[points.length - 1];
  // Black primaries vanish as a line on a dark tile; swap to the secondary.
  const color = readableTeamColor(team.identity, "#141416", BRAND);

  return (
    <Body
      cycle={i}
      live={slides.length > 1}
      top={
        <>
          <Rotator count={slides.length} onTick={() => setI((v) => (v + 1) % slides.length)} />
          <Text fontSize="6.5cqmin" fontWeight="black" fontStyle="italic" color="white" textTransform="uppercase" lineHeight={0.9} letterSpacing="-0.03em" lineClamp={1} textAlign="center">
            Trends
          </Text>
        </>
      }
    >
      <Box position="relative" flex={1} minH="36cqmin" minW={0}>
        <Flex position="absolute" inset={0} align="center" justify="center" opacity={0.2} pointerEvents="none">
          <Mark logo={team.identity.logo} label={team.identity.short} size={46} />
        </Flex>
        <Flex position="relative" direction="column" align="center" justify="center" h="100%" minW={0} textAlign="center">
          <Text fontSize="13cqmin" fontWeight="black" fontStyle="italic" color="white" lineHeight={0.9} letterSpacing="-0.05em" fontVariantNumeric="tabular-nums" lineClamp={1} textShadow="0 0 2cqmin rgba(0,0,0,0.8)">
            {stat.signed ? fmtSigned(latest, 2) : fmtMetric(latest, stat.unit)}
          </Text>
          <Context mt="1cqmin" color="rgba(255,255,255,0.8)" textAlign="center">{stat.label}</Context>
          <Box w="100%" h="10cqmin" mt="1.6cqmin" px="1cqmin">
            <Sparkline points={points} color={color} />
          </Box>
        </Flex>
      </Box>
    </Body>
  );
};

// ── Glossary — the six ideas the rest of the hub is built on ─────────────────
// The other seven tiles sell a number you absorb in half a second. This one is
// asking you to learn something, so it gets a beat of its own: each term runs
// as TWO slides — the word, then the arithmetic — and each face owns the whole
// tile rather than splitting it.
//
// That split is the whole point. `cqmin` here resolves against the strip's
// short side, so body copy set at the 2.4cqmin the other tiles use lands near
// 6px and is decoration, not text. Giving the formula its own slide buys it
// 6cqmin and makes it readable. Wording and math both come from the glossary
// object the tab and every tooltip read, so there is one definition on the site.

const TILE_TERMS = [
  "Expected Points Added",
  "Success Rate",
  "Havoc Rate",
  "OL Line Yards",
  "Highlight Yards",
  "Stuffed Run",
];

const MathLine = ({ children, size }) => (
  <Text fontSize={`${size}cqmin`} fontWeight="bold" color="rgba(255,255,255,0.9)" lineHeight={1.25} textAlign="center">
    {children}
  </Text>
);

// A ratio is drawn as one: numerator over a rule over denominator. Anything
// that is not a ratio is a single condition line, set larger.
const Formula = ({ math }) => {
  if (!math) return null;
  if (math.expr) return <MathLine size={6.4}>{math.expr}</MathLine>;
  return (
    <Box>
      <MathLine size={5.6}>{math.num}</MathLine>
      <Box h="1px" bg="rgba(255,255,255,0.45)" my="1.6cqmin" />
      <MathLine size={5.6}>{math.den}</MathLine>
    </Box>
  );
};

const GlossaryBody = () => {
  // Two slides per term — the word, then its math. A term with no math on file
  // simply does not get a second slide.
  const slides = useMemo(
    () =>
      TILE_TERMS.map(glossaryEntry)
        .filter(Boolean)
        .flatMap((t) => (t.math ? [{ t, math: false }, { t, math: true }] : [{ t, math: false }])),
    [],
  );
  const [i, setI] = useState(0);
  const slide = slides[i % Math.max(1, slides.length)];
  if (!slide) return <Empty>No glossary</Empty>;
  const { t, math } = slide;
  return (
    <Body
      cycle={i}
      live={slides.length > 1}
      top={<Rotator count={slides.length} onTick={() => setI((v) => (v + 1) % slides.length)} />}
      // On a math slide the footer names the term the formula belongs to, so a
      // glance that lands mid-pair is not looking at an orphan fraction.
      tease={
        math ? (
          <Micro size={2.8} color="rgba(255,255,255,0.6)">{t.term}</Micro>
        ) : (
          <Micro size={2.2}>{t.family}{t.source === "gop" ? " · GOP" : ""}</Micro>
        )
      }
    >
      {math ? (
        <Formula math={t.math} />
      ) : (
        <Hero size={9.6} fontStyle="italic" textTransform="uppercase" lineClamp={4} lineHeight={0.9}>
          {t.term}
        </Hero>
      )}
    </Body>
  );
};

// ── Strip ────────────────────────────────────────────────────────────────────

// Ids and labels are the shared list (page validation + sidebar sub-items
// read the same one); the strip only adds each tab's icon and live body.
// `rotateMs` is the tile's base clock (5–12s band); Rotator re-draws a fresh
// interval off it every cycle, so no two flips are ever the same distance
// apart. `transition` is how it moves from one slide
// to the next (the .ta-x-* set in TILE_KEYFRAMES): slide · push · flip ·
// cube · peek · fade · zoom.
const TILE_PARTS = {
  week: { icon: CalendarDays, Body: WeekBody, rotateMs: 7000, transition: "slide" },
  profile: { icon: Shield, Body: ProfileBody, rotateMs: 9000, transition: "flip" },
  board: { icon: BarChart3, Body: BoardBody, rotateMs: 5500, transition: "push" },
  map: { icon: Map, Body: MapBody, rotateMs: 10000, transition: "fade" },
  matchup: { icon: Swords, Body: MatchupBody, rotateMs: 9000, transition: "flip" },
  lab: { icon: Grid3x3, Body: LabBody, rotateMs: 6500, transition: "peek" },
  trends: { icon: TrendingUp, Body: TrendsBody, rotateMs: 8000, transition: "slide" },
  glossary: { icon: BookOpen, Body: GlossaryBody, rotateMs: 12000, transition: "zoom" },
};
const TILES = TEAM_ANALYTICS_TABS.map((t) => ({ ...t, ...TILE_PARTS[t.id] }));

export const TeamAnalyticsTileStrip = ({ tab, onSelect, hub, review, season, teamId, teamA, teamB }) => (
  <Box h="100%" w="100%" containerType="size">
    <style>{TILE_KEYFRAMES}</style>
    <Grid templateColumns="repeat(8, minmax(0, 1fr))" gap="1.5cqmin" h="100%" w="100%">
      {TILES.map(({ id, label, icon: Icon, Body: TileBody, rotateMs, transition }, index) => {
        const active = tab === id;
        return (
          <Flex
            key={id}
            as="button"
            type="button"
            onClick={() => onSelect(id)}
            aria-pressed={active}
            className="group ta-tile-mount"
            style={{ "--ta-rotate": `${rotateMs || DEFAULT_ROTATE_MS}ms`, "--ta-mount-delay": `${index * 70}ms` }}
            direction="column"
            minW={0}
            minH={0}
            h="100%"
            p={0}
            gap={0}
            textAlign="left"
            borderRadius="lg"
            border="1px solid"
            borderColor={active ? BRAND : "whiteAlpha.100"}
            bg={active ? `linear-gradient(180deg, ${BRAND}33 0%, rgba(20,20,22,0.96) 55%, #141416 100%)` : "#141416"}
            boxShadow={active ? `inset 0 0 0 1px ${BRAND}66, 0 12px 30px rgba(0,0,0,0.35)` : "none"}
            position="relative"
            overflow="hidden"
            transition="border-color 0.15s, background 0.15s"
          >
            <Box position="absolute" right="-4cqmin" top="-2cqmin" w="20cqmin" h="20cqmin" opacity={active ? 0.12 : 0.05} pointerEvents="none" color={active ? BRAND : "white"}>
              <Icon size="100%" strokeWidth={1.5} />
            </Box>

            <Flex direction="column" flex={1} minH={0} position="relative" zIndex={1} p="3cqmin" pb="2cqmin">
              <TileConfig.Provider value={{ rotateMs: rotateMs || DEFAULT_ROTATE_MS, transition: transition ?? "slide" }}>
                <TileBody hub={hub} review={review} season={season} teamId={teamId} teamA={teamA} teamB={teamB} />
              </TileConfig.Provider>
            </Flex>

            {/* The tab IS the tile's footer: edge to edge, square corners,
                no inset. Icon, big label with its "Viewing / Open tab"
                caption stacked under it, and the arrow that says "open it".
                Active = solid brand; idle = dark bar that lifts on hover. */}
            <Flex
              align="center"
              gap="2cqmin"
              flexShrink={0}
              position="relative"
              zIndex={1}
              w="100%"
              px="3cqmin"
              py="3.75cqmin"
              borderTop="1px solid"
              borderColor={active ? "transparent" : "whiteAlpha.100"}
              bg={active ? BRAND : "rgba(255,255,255,0.06)"}
              color="white"
              transition="background 0.15s"
            >
              <Box w="6cqmin" h="6cqmin" flexShrink={0} color={active ? "white" : BRAND}><Icon size="100%" strokeWidth={2.5} /></Box>
              <Flex direction="column" gap="1.2cqmin" flex={1} minW={0}>
                <Text fontSize="5.2cqmin" fontWeight="black" color="white" textTransform="uppercase" letterSpacing="0.06em" lineHeight={0.95} lineClamp={2}>
                  {label}
                </Text>
                <Text fontSize="2.4cqmin" fontWeight="black" color={active ? "rgba(255,255,255,0.75)" : "rgba(255,255,255,0.4)"} textTransform="uppercase" letterSpacing="0.16em" lineHeight={1}>
                  {active ? "Viewing" : "Open tab"}
                </Text>
              </Flex>
              <Box w="5cqmin" h="5cqmin" flexShrink={0} opacity={active ? 1 : 0.7}>
                <ArrowRight size="100%" strokeWidth={2.8} />
              </Box>
            </Flex>
          </Flex>
        );
      })}
    </Grid>
  </Box>
);

export default TeamAnalyticsTileStrip;
