import { GameCenterContextCardsA } from "./GameCenterContextCardsA";
import { GameBannerMobileA } from "./GameBannerMobileA";

const registry = [
  {
    number: 1711,
    name: "Game Center Hub - Context Cards (15)",
    agent: "Claude",
    date: "2026-10-04",
    size: "4x8",
    component: GameCenterContextCardsA,
    hideOverlay: true,
  },
  {
    number: 1710,
    name: "Game Page - Banner - Mobile",
    agent: "Claude",
    date: "2026-10-03",
    size: "4x2",
    component: GameBannerMobileA,
    hideOverlay: true,
  },
];

// Diagnostic: Log invalid component types
registry.forEach((entry) => {
  if (typeof entry.component !== "function") {
    // eslint-disable-next-line no-console
    console.warn(
      `[LAB REGISTRY WARNING] Entry #${entry.number} (${entry.name}) has invalid component type:`,
      typeof entry.component,
      entry.component
    );
  }
});

export { registry };
